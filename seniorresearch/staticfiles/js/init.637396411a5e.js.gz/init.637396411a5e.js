(function($){
  $(function(){

    $('.button-collapse').sideNav();

  }); // end of document ready
})(jQuery); // end of jQuery name space

/*
$(window).scroll(function () { 
    //You've scrolled this much:
       if($(window).scrollTop() > 0) {
        $("#main_nav").addClass("ao");
       } else {
        $("#main_nav").removeClass("ao");
       }
});
*/